# Repositorio del curso de JavaScript Avanzado: "Paradigmas de Programación" de EDteam 2017 impartido por @jonmircha

### [Ir al Curso](https://ed.team/cursos/javascript-avanzado)

### [Ver Presentación](http://jonmircha.github.io/edjs-paradigmas2017)

### [Ver Proyecto](http://jonmircha.github.io/edjs-paradigmas2017/todo_list.html)

![JavaScript Avanzado: Paradigmas de Programación](https://ed.team/sites/default/files/styles/large/public/courses/images/jsAvanzado-poster_1.png?itok=hzt5hlnZ)
