const ENTER_KEY = 13,
  c = console.log,
  d = document,
  j = JSON,
  ls = localStorage

export {
  ENTER_KEY,
  c,
  d,
  j,
  ls
}