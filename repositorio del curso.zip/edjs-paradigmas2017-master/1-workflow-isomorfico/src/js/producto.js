export default function producto (a, b) {
  return a * b
}

export function cuadrado (a) {
  return a * a
}

export function potencia (b, e) {
  return Math.pow(b, e)
}