export default function division (a, b) {
  return a / b
}

export function modulo (a, b) {
  return a % b
}